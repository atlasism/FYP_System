<?php
require_once '../config/database.php';
require_once '../includes/auth_check.php';
check_access(['Student']);

if (!function_exists('sanitize')) {
    function sanitize($data) {
        return htmlspecialchars(trim($data ?? ''), ENT_QUOTES, 'UTF-8');
    }
}

$student_id = $_SESSION['user_id'] ?? 0;

// Cari project_id pelajar ini sama ada sebagai ketua (projects.student_id) atau ahli (project_members)
$project_query = "
    SELECT p.id as project_id 
    FROM projects p 
    LEFT JOIN project_members pm ON p.id = pm.project_id 
    WHERE p.student_id = ? OR pm.student_id = ? 
    LIMIT 1
";
$stmt = $conn->prepare($project_query);
$stmt->bind_param("ii", $student_id, $student_id);
$stmt->execute();
$project_res = $stmt->get_result();

$marks = null;
if ($project_res->num_rows > 0) {
    $project = $project_res->fetch_assoc();
    $project_id = $project['project_id'];

    // Ambil markah daripada jadual project_marks berdasarkan project_id
    $marks_query = "SELECT * FROM project_marks WHERE project_id = ?";
    $stmt_m = $conn->prepare($marks_query);
    $stmt_m->bind_param("i", $project_id);
    $stmt_m->execute();
    $marks = $stmt_m->get_result()->fetch_assoc();
}

include_once '../includes/header.php';
include_once '../includes/sidebar_student.php'; // Sesuaikan dengan sidebar pelajar anda
?>

<div class="container-fluid py-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h4 class="fw-bold text-primary mb-1"><i class="fas fa-chart-line me-2"></i>Project Evaluation Marks</h4>
            <p class="text-muted mb-0">Percentage weight breakdown (100%) by document type and current evaluation status.</p>
        </div>
        <div>
            <span class="badge bg-primary px-3 py-2 fs-6"><i class="fas fa-weight-hanging me-1"></i> Total Weight: 100%</span>
        </div>
    </div>

    <div class="row">
        <!-- Kotak Markah Keseluruhan -->
        <div class="col-lg-4 mb-4">
            <div class="card border-0 shadow-sm rounded-3 bg-white h-100">
                <div class="card-body text-center p-4 d-flex flex-column justify-content-between">
                    <div>
                        <span class="text-uppercase fw-bold text-muted small d-block mb-3">Total Overall Score</span>
                        <h1 class="fw-bold text-primary display-4 mb-3">
                            <?= isset($marks['total_score']) ? number_format($marks['total_score'], 1) : '0.0'; ?> <span class="fs-4 text-muted">/100%</span>
                        </h1>
                        <?php 
                            $total = $marks['total_score'] ?? 0;
                            if ($total > 0) {
                                echo '<span class="badge bg-success px-3 py-2"><i class="fas fa-check-circle me-1"></i> Evaluated</span>';
                            } else {
                                echo '<span class="badge bg-warning text-dark px-3 py-2"><i class="fas fa-hourglass-half me-1"></i> Not Evaluated Yet</span>';
                            }
                        ?>
                    </div>
                    <div class="text-start mt-4 pt-3 border-top">
                        <small class="text-muted fw-bold d-block mb-1">Evaluation Status:</small>
                        <p class="small text-muted mb-0">
                            <?= $total > 0 ? 'Your project has been graded by your supervisor.' : 'Document-based evaluation is currently in progress or has not been graded by the Supervisor yet.'; ?>
                        </p>
                    </div>
                </div>
            </div>
        </div>

        <!-- Pecahan Markah Mengikut Dokumen -->
        <div class="col-lg-8 mb-4">
            <div class="card border-0 shadow-sm rounded-3 bg-white">
                <div class="card-header bg-light py-3">
                    <h5 class="fw-bold text-dark mb-0"><i class="fas fa-list-alt me-2 text-primary"></i>Score Breakdown by Document Type (100%):</h5>
                </div>
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table table-hover align-middle mb-0">
                            <thead class="table-light text-secondary small">
                                <tr>
                                    <th class="py-3 ps-4">Document Type</th>
                                    <th class="py-3 text-center">Weight (%)</th>
                                    <th class="py-3 text-center">Status / Progress</th>
                                    <th class="py-3 pe-4 text-end">Score</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php 
                                $rubrics = [
                                    ['name' => 'proposal', 'label' => 'Project Proposal', 'desc' => 'Proposal', 'max' => 15, 'icon' => 'fa-file-alt'],
                                    ['name' => 'final_report', 'label' => 'Final Report', 'desc' => 'Final Report', 'max' => 30, 'icon' => 'fa-file-pdf'],
                                    ['name' => 'slides', 'label' => 'Presentation Slides', 'desc' => 'Presentation Slides', 'max' => 15, 'icon' => 'fa-file-powerpoint'],
                                    ['name' => 'poster', 'label' => 'Project Poster', 'desc' => 'Poster', 'max' => 10, 'icon' => 'fa-image'],
                                    ['name' => 'source_code', 'label' => 'Gantt Chart / Source Code', 'desc' => 'Source Code', 'max' => 15, 'icon' => 'fa-code'],
                                    ['name' => 'system_image', 'label' => 'System Preview / Image', 'desc' => 'Project Image', 'max' => 10, 'icon' => 'fa-desktop'],
                                    ['name' => 'other_docs', 'label' => 'Other Documents (Additional)', 'desc' => 'Document Lain', 'max' => 5, 'icon' => 'fa-file-archive'],
                                ];

                                foreach ($rubrics as $r):
                                    $has_val = isset($marks[$r['name']]) && $marks[$r['name']] > 0;
                                    $val = $marks[$r['name']] ?? 0;
                                ?>
                                <tr>
                                    <td class="ps-4">
                                        <div class="d-flex align-items-center">
                                            <i class="fas <?= $r['icon']; ?> text-primary fa-lg me-3"></i>
                                            <div>
                                                <div class="fw-bold text-dark"><?= $r['label']; ?></div>
                                                <small class="text-muted"><?= $r['desc']; ?></small>
                                            </div>
                                        </div>
                                    </td>
                                    <td class="text-center">
                                        <span class="badge bg-info text-dark px-2 py-1"><?= $r['max']; ?>%</span>
                                    </td>
                                    <td class="text-center">
                                        <?php if ($has_val): ?>
                                            <span class="badge bg-success-subtle text-success border border-success-subtle px-2 py-1">Evaluated</span>
                                        <?php else: ?>
                                            <span class="text-muted small">Not Evaluated</span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="pe-4 text-end fw-bold">
                                        <span class="<?= $has_val ? 'text-success' : 'text-muted'; ?>">
                                            <?= $has_val ? number_format($val, 1) : '-'; ?> / <?= $r['max']; ?>
                                        </span>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include_once '../includes/footer.php'; ?>