<?php
require_once '../config/database.php';
require_once '../includes/auth_check.php';
check_access(['Student']);

$student_id = $_SESSION['user_id'];
$message = '';
$message_type = '';

// 1. Dapatkan ID Projek Pelajar (Ketua ATAU Ahli Kumpulan)
$stmt_proj = $conn->prepare("
    SELECT p.id 
    FROM projects p
    LEFT JOIN project_members pm ON p.id = pm.project_id
    WHERE p.student_id = ? OR pm.student_id = ?
    LIMIT 1
");
$stmt_proj->bind_param("ii", $student_id, $student_id);
$stmt_proj->execute();
$project = $stmt_proj->get_result()->fetch_assoc();

// 2. Proses Muat Naik Dokumen
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['document_file'])) {
    if (!$project) {
        $message = "Please register your project first before uploading documents!";
        $message_type = "danger";
    } else {
        // Tangkap jawapan daripada dropdown secara tepat
        $doc_type = trim($_POST['doc_type'] ?? '');
        $file = $_FILES['document_file'];

        if (empty($doc_type)) {
            $message = "Please select a Document Type from the list!";
            $message_type = "danger";
        } elseif ($file['error'] === UPLOAD_ERR_OK) {
            $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
            $allowed = ['pdf', 'doc', 'docx', 'ppt', 'pptx', 'zip', 'rar', 'jpg', 'jpeg', 'png', 'mp4'];

            if (in_array($ext, $allowed)) {
                $upload_dir = '../uploads/documents/';
                if (!is_dir($upload_dir)) {
                    mkdir($upload_dir, 0777, true);
                }

                $original_name = basename($file['name']);
                $filename = "DOC_" . time() . "_" . rand(100, 999) . "." . $ext;
                $target_path = $upload_dir . $filename;

                if (move_uploaded_file($file['tmp_name'], $target_path)) {
                    // Simpan terus nilai $doc_type yang tepat ke dalam database
                    $stmt_ins = $conn->prepare("INSERT INTO project_documents (project_id, doc_type, file_path, uploaded_at) VALUES (?, ?, ?, NOW())");
                    $stmt_ins->bind_param("iss", $project['id'], $doc_type, $filename);
                    
                    if ($stmt_ins->execute()) {
                        $message = "Document <strong>" . htmlspecialchars($doc_type) . "</strong> uploaded successfully!";
                        $message_type = "success";
                    } else {
                        $message = "Failed to save the record in the database.";
                        $message_type = "danger";
                    }
                } else {
                    $message = "Failed to move the uploaded file.";
                    $message_type = "danger";
                }
            } else {
                $message = "File format not allowed!";
                $message_type = "danger";
            }
        } else {
            $message = "Error during file upload.";
            $message_type = "danger";
        }
    }
}

// 3. Ambil Senarai Dokumen dari Database
$documents = [];
if ($project) {
    $stmt_docs = $conn->prepare("SELECT * FROM project_documents WHERE project_id = ? ORDER BY uploaded_at DESC");
    $stmt_docs->bind_param("i", $project['id']);
    $stmt_docs->execute();
    $res = $stmt_docs->get_result();
    while ($row = $res->fetch_assoc()) {
        $documents[] = $row;
    }
}

// Pemetaan Nama Paparan untuk Jadual
$labels_map = [
    'Proposal'              => 'Project Proposal',
    'Final Report'          => 'Final Report',
    'Presentation Slides' => 'Presentation Slides',
    'Poster'                => 'Project Poster',
    'Source Code'           => 'Gantt Chart / Source Code',
    'Project Image'         => 'System Preview / Image',
    'Demo Video Link'       => 'Demo Video'
];

include_once '../includes/sidebar_student.php';
?>

<!-- Tajuk Halaman -->
<div class="mb-4">
    <h3 class="fw-bold">Upload Project Documents</h3>
    <p class="text-muted">Please select the document type and upload your file.</p>
</div>

<?php if ($message): ?>
    <div class="alert alert-<?= $message_type; ?> alert-dismissible fade show" role="alert">
        <?= $message; ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
<?php endif; ?>

<div class="row g-4">
    <!-- Borang Muat Naik (Sebelah Kiri) -->
    <div class="col-md-5">
        <div class="card card-custom p-4">
            <h5 class="fw-bold mb-3"><i class="fas fa-upload text-primary me-2"></i>Upload Form</h5>
            
            <form action="" method="POST" enctype="multipart/form-data">
                <div class="mb-3">
                    <label class="form-label fw-bold">Document Type</label>
                    <select name="doc_type" class="form-select" required>
                        <option value="">-- Select Document Type --</option>
                        <option value="Proposal">Project Proposal</option>
                        <option value="Final Report">Final Report</option>
                        <option value="Presentation Slides">Presentation Slides</option>
                        <option value="Poster">Project Poster</option>
                        <option value="Source Code">Gantt Chart / Source Code</option>
                        <option value="Project Image">System Preview / Image</option>
                        <option value="Document Lain">Other Documents (If Any)</option>
                    </select>
                </div>

                <div class="mb-3">
                    <label class="form-label fw-bold">Choose File</label>
                    <input type="file" name="document_file" class="form-control" required>
                </div>

                <button type="submit" class="btn btn-primary w-100 fw-bold">
                    <i class="fas fa-cloud-upload-alt me-1"></i> Upload Now
                </button>
            </form>
        </div>
    </div>

    <!-- Kard Senarai Dokumen Dihantar (Sebelah Kanan) -->
    <div class="col-md-7">
        <div class="card card-custom p-4">
            <h5 class="fw-bold mb-3"><i class="fas fa-list text-primary me-2"></i>Submitted Documents List</h5>
            
            <div class="table-responsive">
                <table class="table table-hover align-middle">
                    <thead class="table-light">
                        <tr>
                            <th width="5%">#</th>
                            <th>Document Type</th>
                            <th>Upload Date</th>
                            <th class="text-end">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($documents)): ?>
                            <tr>
                                <td colspan="4" class="text-center text-muted py-3">
                                    No documents uploaded yet.
                                </td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($documents as $index => $doc): ?>
                                <?php 
                                    $raw_type = $doc['doc_type'] ?? '';
                                    
                                    // Tentukan nama jenis dokumen yang hendak dipaparkan
                                    if (!empty($raw_type) && isset($labels_map[$raw_type])) {
                                        $papar_jenis = $labels_map[$raw_type];
                                    } elseif (!empty($raw_type)) {
                                        $papar_jenis = $raw_type;
                                    } else {
                                        $papar_jenis = basename($doc['file_path']);
                                    }
                                ?>
                                <tr>
                                    <td><?= $index + 1; ?></td>
                                    <td>
                                        <span class="fw-bold text-dark">
                                            <?= htmlspecialchars($papar_jenis); ?>
                                        </span>
                                    </td>
                                    <td>
                                        <small class="text-muted">
                                            <?= !empty($doc['uploaded_at']) ? date('d/m/Y h:i A', strtotime($doc['uploaded_at'])) : '-'; ?>
                                        </small>
                                    </td>
                                    <td class="text-end">
                                        <a href="../uploads/documents/<?= htmlspecialchars($doc['file_path']); ?>" class="btn btn-sm btn-outline-primary" download target="_blank">
                                            <i class="fas fa-download me-1"></i> Download
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php include_once '../includes/footer.php'; ?>