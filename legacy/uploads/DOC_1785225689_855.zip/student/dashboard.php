<?php
require_once '../config/database.php';
require_once '../includes/auth_check.php';
check_access(['Student']);

$student_id = $_SESSION['user_id'];

// Ambil maklumat projek pelajar
$stmt = $conn->prepare("SELECT * FROM projects WHERE student_id = ?");
$stmt->bind_param("i", $student_id);
$stmt->execute();
$project = $stmt->get_result()->fetch_assoc();

// Kira dokumen yang dimuat naik
$doc_count = 0;
if ($project) {
    $stmt_doc = $conn->prepare("SELECT COUNT(*) as total FROM project_documents WHERE project_id = ?");
    $stmt_doc->bind_param("i", $project['id']);
    $stmt_doc->execute();
    $doc_count = $stmt_doc->get_result()->fetch_assoc()['total'];
}

include_once '../includes/header.php';
include_once '../includes/navbar.php';
?>

<div class="container py-4">
    <div class="card card-custom p-4 mb-4">
        <h3 class="fw-bold text-primary mb-1">Papan Pemuka Pelajar</h3>
        <p class="text-muted mb-0">Selamat datang, <strong><?= sanitize($_SESSION['full_name']); ?></strong> (<?= sanitize($_SESSION['department']); ?>)</p>
    </div>

    <!-- Kad Kad Statistik -->
    <div class="row g-4 mb-4">
        <div class="col-md-4">
            <div class="card card-custom p-3 border-start border-primary border-4">
                <div class="d-flex align-items-center">
                    <div class="p-3 bg-primary bg-opacity-10 text-primary rounded me-3">
                        <i class="fas fa-project-diagram fa-2x"></i>
                    </div>
                    <div>
                        <small class="text-muted">Status Pendaftaran</small>
                        <h6 class="fw-bold mb-0"><?= $project ? 'Berjaya Didaftarkan' : 'Belum Mendaftar'; ?></h6>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card card-custom p-3 border-start border-warning border-4">
                <div class="d-flex align-items-center">
                    <div class="p-3 bg-warning bg-opacity-10 text-warning rounded me-3">
                        <i class="fas fa-file-upload fa-2x"></i>
                    </div>
                    <div>
                        <small class="text-muted">Dokumen Dimuat Naik</small>
                        <h6 class="fw-bold mb-0"><?= $doc_count; ?> Fail</h6>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card card-custom p-3 border-start border-success border-4">
                <div class="d-flex align-items-center">
                    <div class="p-3 bg-success bg-opacity-10 text-success rounded me-3">
                        <i class="fas fa-check-circle fa-2x"></i>
                    </div>
                    <div>
                        <small class="text-muted">Kelayakan Penilaian</small>
                        <h6 class="fw-bold mb-0"><?= ($project && $project['is_complete_for_evaluation']) ? 'Layak Evaluasi' : 'Belum Lengkap'; ?></h6>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Tindakan Cepat -->
    <div class="card card-custom p-4">
        <h5 class="fw-bold mb-3">Tindakan Pelajar</h5>
        <div class="row g-3">
            <?php if (!$project): ?>
                <div class="col-md-6">
                    <a href="register_project.php" class="btn btn-primary w-100 py-3 fw-bold"><i class="fas fa-plus-circle me-2"></i>Daftar Projek FYP Baru</a>
                </div>
            <?php else: ?>
                <div class="col-md-4">
                    <a href="my_project.php" class="btn btn-outline-primary w-100 py-3 fw-bold"><i class="fas fa-eye me-2"></i>Lihat & Edit Projek</a>
                </div>
                <div class="col-md-4">
                    <a href="upload_documents.php" class="btn btn-outline-warning text-dark w-100 py-3 fw-bold"><i class="fas fa-upload me-2"></i>Muat Naik Dokumen Wajib</a>
                </div>
            <?php endif; ?>
            <div class="col-md-4">
                <a href="profile.php" class="btn btn-outline-secondary w-100 py-3 fw-bold"><i class="fas fa-user-cog me-2"></i>Kemaskini Profil</a>
            </div>
        </div>
    </div>
</div>

<?php include_once '../includes/footer.php'; ?>