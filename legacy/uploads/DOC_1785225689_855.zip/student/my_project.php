<?php
require_once '../config/database.php';
require_once '../includes/auth_check.php';
check_access(['Student']);

$student_id = $_SESSION['user_id'];
$message = '';

// Kemaskini data projek
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = trim($_POST['title']);
    $category = trim($_POST['category']);
    $description = trim($_POST['description']);

    $stmt_up = $conn->prepare("UPDATE projects SET title = ?, category = ?, description = ? WHERE student_id = ?");
    $stmt_up->bind_param("sssi", $title, $category, $description, $student_id);
    if ($stmt_up->execute()) {
        $message = "Maklumat projek berjaya dikemaskini.";
    }
}

// Ambil maklumat projek
$stmt = $conn->prepare("SELECT * FROM projects WHERE student_id = ?");
$stmt->bind_param("i", $student_id);
$stmt->execute();
$project = $stmt->get_result()->fetch_assoc();

if (!$project) {
    header("Location: register_project.php");
    exit();
}

include_once '../includes/header.php';
include_once '../includes/navbar.php';
?>

<div class="container py-4">
    <div class="card card-custom p-4 mb-4">
        <div class="d-flex justify-content-between align-items-center">
            <h4 class="fw-bold mb-0"><i class="fas fa-folder-open me-2 text-primary"></i>Maklumat Projek Saya</h4>
            <span class="badge bg-primary px-3 py-2"><?= sanitize($project['status']); ?></span>
        </div>
    </div>

    <?php if ($message): ?><div class="alert alert-success py-2"><?= sanitize($message); ?></div><?php endif; ?>

    <div class="card card-custom p-4">
        <form method="POST">
            <div class="mb-3">
                <label class="form-label fw-bold">Tajuk Projek</label>
                <input type="text" name="title" class="form-control" value="<?= sanitize($project['title']); ?>" required>
            </div>

            <div class="row">
                <div class="col-md-6 mb-3">
                    <label class="form-label fw-bold">Jabatan</label>
                    <input type="text" class="form-control" value="<?= sanitize($project['department']); ?>" readonly>
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label fw-bold">Kategori Projek</label>
                    <input type="text" name="category" class="form-control" value="<?= sanitize($project['category']); ?>" required>
                </div>
            </div>

            <div class="mb-3">
                <label class="form-label fw-bold">Penerangan Projek</label>
                <textarea name="description" rows="5" class="form-control" required><?= sanitize($project['description']); ?></textarea>
            </div>

            <button type="submit" class="btn btn-warning text-dark fw-bold"><i class="fas fa-save me-1"></i> Kemaskini Projek</button>
            <a href="upload_documents.php" class="btn btn-primary fw-bold ms-2"><i class="fas fa-file-upload me-1"></i> Ke Halaman Dokumen</a>
        </form>
    </div>
</div>

<?php include_once '../includes/footer.php'; ?>