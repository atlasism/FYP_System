<?php
require_once '../config/database.php';
require_once '../includes/auth_check.php';
check_access(['Student']);

$student_id = $_SESSION['user_id'];

// Ambil ID projek
$stmt_proj = $conn->prepare("SELECT id FROM projects WHERE student_id = ?");
$stmt_proj->bind_param("i", $student_id);
$stmt_proj->execute();
$project = $stmt_proj->get_result()->fetch_assoc();

if (!$project) {
    header("Location: register_project.php");
    exit();
}

$project_id = $project['id'];
$message = '';
$error = '';

// Jenis dokumen yang disokong
$required_docs = ['Proposal', 'Final Report', 'Presentation Slides', 'Poster', 'Source Code'];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['doc_file'])) {
    $doc_type = $_POST['doc_type'];
    $file = $_FILES['doc_file'];

    if (in_array($doc_type, $required_docs) && $file['error'] === 0) {
        $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        $new_filename = $project_id . '_' . time() . '_' . preg_replace("/[^a-zA-Z0-9]/", "", $doc_type) . '.' . $ext;
        $target_dir = "../uploads/";

        if (move_uploaded_file($file['tmp_name'], $target_dir . $new_filename)) {
            // Padam rekod lama bagi jenis dokumen yang sama
            $stmt_del = $conn->prepare("DELETE FROM project_documents WHERE project_id = ? AND doc_type = ?");
            $stmt_del->bind_param("is", $project_id, $doc_type);
            $stmt_del->execute();

            // Masukkan rekod baharu
            $stmt_ins = $conn->prepare("INSERT INTO project_documents (project_id, doc_type, file_path) VALUES (?, ?, ?)");
            $stmt_ins->bind_param("iss", $project_id, $doc_type, $new_filename);
            $stmt_ins->execute();

            // Semak jika SEMUA dokumen wajib telah di-upload
            $stmt_chk = $conn->prepare("SELECT DISTINCT doc_type FROM project_documents WHERE project_id = ?");
            $stmt_chk->bind_param("i", $project_id);
            $stmt_chk->execute();
            $uploaded_types = [];
            $res = $stmt_chk->get_result();
            while($r = $res->fetch_assoc()) {
                $uploaded_types[] = $r['doc_type'];
            }

            $is_complete = 1;
            foreach ($required_docs as $req) {
                if (!in_array($req, $uploaded_types)) {
                    $is_complete = 0;
                    break;
                }
            }

            // Kemaskini status projek
            $stmt_status = $conn->prepare("UPDATE projects SET is_complete_for_evaluation = ? WHERE id = ?");
            $stmt_status->bind_param("ii", $is_complete, $project_id);
            $stmt_status->execute();

            $message = "Dokumen (" . $doc_type . ") berjaya dimuat naik.";
        } else {
            $error = "Gagal menyimpan fail ke pelayan.";
        }
    } else {
        $error = "Sila pilih fail yang sah.";
    }
}

// Ambil senarai dokumen yang telah dimuat naik
$stmt_docs = $conn->prepare("SELECT * FROM project_documents WHERE project_id = ?");
$stmt_docs->bind_param("i", $project_id);
$stmt_docs->execute();
$uploaded_docs_res = $stmt_docs->get_result();
$uploaded_list = [];
while($d = $uploaded_docs_res->fetch_assoc()) {
    $uploaded_list[$d['doc_type']] = $d;
}

include_once '../includes/header.php';
include_once '../includes/navbar.php';
?>

<div class="container py-4">
    <div class="card card-custom p-4 mb-4">
        <h4 class="fw-bold mb-1"><i class="fas fa-file-upload me-2 text-primary"></i>Pengurusan Dokumen FYP</h4>
        <p class="text-muted mb-0">Semua dokumen wajib berikut mesti dimuat naik sebelum fungsi penilaian dibuka untuk Panel SPInE.</p>
    </div>

    <?php if ($message): ?><div class="alert alert-success py-2"><?= sanitize($message); ?></div><?php endif; ?>
    <?php if ($error): ?><div class="alert alert-danger py-2"><?= sanitize($error); ?></div><?php endif; ?>

    <div class="row g-4">
        <!-- Borang Upload -->
        <div class="col-md-5">
            <div class="card card-custom p-4">
                <h5 class="fw-bold mb-3">Muat Naik Fail</h5>
                <form method="POST" enctype="multipart/form-data">
                    <div class="mb-3">
                        <label class="form-label fw-bold">Jenis Dokumen</label>
                        <select name="doc_type" class="form-select" required>
                            <?php foreach ($required_docs as $type): ?>
                                <option value="<?= $type; ?>"><?= $type; ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-bold">Pilih Fail (PDF, ZIP, PNG, JPG)</label>
                        <input type="file" name="doc_file" class="form-control" required>
                    </div>
                    <button type="submit" class="btn btn-primary w-100 fw-bold"><i class="fas fa-upload me-1"></i> Muat Naik Dokumen</button>
                </form>
            </div>
        </div>

        <!-- Senarai Semak Dokumen -->
        <div class="col-md-7">
            <div class="card card-custom p-4">
                <h5 class="fw-bold mb-3">Status Dokumen Wajib</h5>
                <div class="table-responsive">
                    <table class="table table-bordered align-middle">
                        <thead class="table-light">
                            <tr>
                                <th>Jenis Dokumen</th>
                                <th>Status</th>
                                <th>Tindakan</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($required_docs as $req_doc): ?>
                                <tr>
                                    <td class="fw-bold"><?= $req_doc; ?></td>
                                    <td>
                                        <?php if (isset($uploaded_list[$req_doc])): ?>
                                            <span class="badge bg-success"><i class="fas fa-check me-1"></i> Selesai</span>
                                        <?php else: ?>
                                            <span class="badge bg-danger"><i class="fas fa-times me-1"></i> Belum Diumat Naik</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if (isset($uploaded_list[$req_doc])): ?>
                                            <a href="../uploads/<?= sanitize($uploaded_list[$req_doc]['file_path']); ?>" target="_blank" class="btn btn-sm btn-outline-primary"><i class="fas fa-download"></i> Muat Turun</a>
                                        <?php else: ?>
                                            <span class="text-muted small">-</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include_once '../includes/footer.php'; ?>