<?php
require_once '../config/database.php';
require_once '../includes/auth_check.php';
check_access(['Student']);

$student_id = $_SESSION['user_id'];

// 1. Ambil Maklumat Projek & Penyelia
$stmt = $conn->prepare("
    SELECT p.*, s.full_name as supervisor_name 
    FROM projects p 
    LEFT JOIN users s ON p.supervisor_id = s.id 
    WHERE p.student_id = ?
");
$stmt->bind_param("i", $student_id);
$stmt->execute();
$project = $stmt->get_result()->fetch_assoc();

// 2. Ambil Senarai & Status Dokumen yang Telah Dimuat Naik
$uploaded_docs = [];
if ($project) {
    $stmt_doc = $conn->prepare("SELECT doc_type, file_path FROM project_documents WHERE project_id = ?");
    $stmt_doc->bind_param("i", $project['id']);
    $stmt_doc->execute();
    $res = $stmt_doc->get_result();
    while ($row = $res->fetch_assoc()) {
        $uploaded_docs[$row['doc_type']] = $row['file_path'];
    }
}

// Senarai dokumen utama untuk disemak
$doc_list = [
    'Proposal' => 'Proposal Projek',
    'Report'   => 'Laporan Akhir (Draft)',
    'Poster'   => 'Poster Projek',
    'Slides'   => 'Slaid Pembentangan',
    'Gantt'    => 'Gantt Chart / Kod Sumber'
];

include_once '../includes/sidebar_student.php';
?>

<!-- Tajuk Dashboard -->
<div class="d-flex align-items-center justify-content-between mb-4">
    <div>
        <h3 class="fw-bold mb-1">Selamat Datang, <?= sanitize($_SESSION['full_name'] ?? 'Pelajar'); ?>! 👋</h3>
        <p class="text-muted mb-0">Berikut adalah ringkasan status kemajuan projek dan penghantaran dokumen anda.</p>
    </div>
    <?php if (!$project): ?>
        <a href="register_project.php" class="btn btn-primary fw-bold">
            <i class="fas fa-plus-circle me-1"></i> Daftar Projek
        </a>
    <?php endif; ?>
</div>

<!-- Cad Widget Ringkasan Utama -->
<div class="row g-3 mb-4">
    <!-- Status Projek -->
    <div class="col-md-4">
        <div class="card card-custom p-3 border-start border-4 border-warning h-100">
            <div class="d-flex justify-content-between align-items-center">
                <div>
                    <small class="text-muted fw-bold d-block mb-1">STATUS PROJEK</small>
                    <h5 class="fw-bold mb-0 text-dark">
                        <?php 
                        if (!$project) {
                            echo '<span class="badge bg-secondary">Belum Berdaftar</span>';
                        } elseif ($project['is_complete_for_evaluation'] ?? 0) {
                            echo '<span class="badge bg-success">Lengkap & Bersedia</span>';
                        } else {
                            echo '<span class="badge bg-warning text-dark">Dalam Kemajuan</span>';
                        }
                        ?>
                    </h5>
                </div>
                <div class="bg-warning bg-opacity-10 p-3 rounded-circle text-warning">
                    <i class="fas fa-hourglass-half fa-2x"></i>
                </div>
            </div>
        </div>
    </div>

    <!-- Tajuk Projek / Kategori -->
    <div class="col-md-4">
        <div class="card card-custom p-3 border-start border-4 border-primary h-100">
            <div class="d-flex justify-content-between align-items-center">
                <div>
                    <small class="text-muted fw-bold d-block mb-1">KATEGORI PROJEK</small>
                    <h5 class="fw-bold mb-0 text-primary">
                        <?= sanitize($project['category'] ?? 'Tiada Kategori'); ?>
                    </h5>
                </div>
                <div class="bg-primary bg-opacity-10 p-3 rounded-circle text-primary">
                    <i class="fas fa-project-diagram fa-2x"></i>
                </div>
            </div>
        </div>
    </div>

    <!-- Penyelia -->
    <div class="col-md-4">
        <div class="card card-custom p-3 border-start border-4 border-info h-100">
            <div class="d-flex justify-content-between align-items-center">
                <div>
                    <small class="text-muted fw-bold d-block mb-1">PENYELIA (SUPERVISOR)</small>
                    <h6 class="fw-bold mb-0 text-dark">
                        <?= sanitize($project['supervisor_name'] ?? 'Belum Ditentukan'); ?>
                    </h6>
                </div>
                <div class="bg-info bg-opacity-10 p-3 rounded-circle text-info">
                    <i class="fas fa-user-tie fa-2x"></i>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Modul Semakan Penghantaran Dokumen -->
<div class="card card-custom p-4 mb-4">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h5 class="fw-bold mb-0"><i class="fas fa-file-upload text-primary me-2"></i>Status Penghantaran Dokumen</h5>
        <a href="upload_documents.php" class="btn btn-outline-primary btn-sm fw-bold">
            <i class="fas fa-upload me-1"></i> Muat Naik Fail
        </a>
    </div>

    <div class="row g-3">
        <?php foreach ($doc_list as $key => $label): ?>
            <?php 
                // Semak samada dokumen wujud dalam pangkalan data
                $is_uploaded = false;
                foreach ($uploaded_docs as $doc_type => $path) {
                    if (stripos($doc_type, $key) !== false || stripos($doc_type, $label) !== false) {
                        $is_uploaded = true;
                        break;
                    }
                }
            ?>
            <div class="col-md-4 col-6">
                <div class="p-3 border rounded-3 d-flex align-items-center justify-content-between bg-light">
                    <div>
                        <span class="fw-bold d-block text-dark small"><?= $label; ?></span>
                        <small class="<?= $is_uploaded ? 'text-success fw-bold' : 'text-danger'; ?>">
                            <i class="fas <?= $is_uploaded ? 'fa-check-circle' : 'fa-times-circle'; ?> me-1"></i>
                            <?= $is_uploaded ? 'Telah Dimuat Naik' : 'Belum Ada'; ?>
                        </small>
                    </div>
                    <div>
                        <?php if ($is_uploaded): ?>
                            <span class="badge bg-success"><i class="fas fa-check"></i></span>
                        <?php else: ?>
                            <span class="badge bg-secondary"><i class="fas fa-clock"></i></span>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
</div>

<!-- Maklumat Ringkas Projek Pelajar -->
<?php if ($project): ?>
<div class="card card-custom p-4">
    <h5 class="fw-bold text-dark mb-2"><i class="fas fa-info-circle text-info me-2"></i>Maklumat Ringkas Projek</h5>
    <div class="row">
        <div class="col-md-8">
            <p class="mb-1"><strong>Tajuk Projek:</strong> <?= sanitize($project['title'] ?? '-'); ?></p>
            <p class="mb-1 text-muted small"><strong>Keterangan Ringkas:</strong> <?= sanitize($project['description'] ?? 'Tiada penerangan diberikan.'); ?></p>
        </div>
        <div class="col-md-4 text-md-end border-start">
            <p class="mb-1 small text-muted"><strong>Sesi Aktiviti:</strong> <?= sanitize($project['session'] ?? 'Sesi Semasa'); ?></p>
            <a href="my_project.php" class="btn btn-sm btn-outline-secondary mt-2">Lihat Butiran Penuh</a>
        </div>
    </div>
</div>
<?php endif; ?>

<?php include_once '../includes/footer_student.php'; ?>