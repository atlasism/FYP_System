<?php
require_once '../config/database.php';
require_once '../includes/auth_check.php';
check_access(['Student']);

// Carian & Penapis
$search = $_GET['search'] ?? '';
$category = $_GET['category'] ?? '';
$session = $_GET['session'] ?? '';

$query = "SELECT p.*, u.full_name, u.department FROM projects p JOIN users u ON p.student_id = u.id WHERE 1=1";
$params = [];
$types = "";

if (!empty($search)) {
    $query .= " AND (p.title LIKE ? OR p.description LIKE ?)";
    $search_param = "%$search%";
    $params[] = $search_param; $params[] = $search_param;
    $types .= "ss";
}
if (!empty($category)) {
    $query .= " AND p.category = ?";
    $params[] = $category;
    $types .= "s";
}
if (!empty($session)) {
    $query .= " AND p.session = ?";
    $params[] = $session;
    $types .= "s";
}

$query .= " ORDER BY p.id DESC";
$stmt = $conn->prepare($query);
if (!empty($params)) {
    $stmt->bind_param($types, ...$params);
}
$stmt->execute();
$past_projects = $stmt->get_result();

include_once '../includes/sidebar_student.php';
?>

<div class="card card-custom p-4 mb-4">
    <h4 class="fw-bold text-primary mb-3"><i class="fas fa-archive me-2"></i>Rujukan Projek-Projek Lepas</h4>
    
    <!-- Borang Penapis -->
    <form method="GET" class="row g-3">
        <div class="col-md-4">
            <input type="text" name="search" class="form-control" placeholder="Cari tajuk / kata kunci..." value="<?= sanitize($search); ?>">
        </div>
        <div class="col-md-3">
            <select name="category" class="form-select">
                <option value="">-- Semua Kategori --</option>
                <option value="Web Based" <?= $category === 'Web Based' ? 'selected' : ''; ?>>Web Based</option>
                <option value="Mobile App" <?= $category === 'Mobile App' ? 'selected' : ''; ?>>Mobile App</option>
                <option value="IoT / Hardware" <?= $category === 'IoT / Hardware' ? 'selected' : ''; ?>>IoT / Hardware</option>
            </select>
        </div>
        <div class="col-md-3">
            <input type="text" name="session" class="form-control" placeholder="Contoh: SESI 1 2024/2025" value="<?= sanitize($session); ?>">
        </div>
        <div class="col-md-2">
            <button type="submit" class="btn btn-primary w-100 fw-bold"><i class="fas fa-search me-1"></i> Cari</button>
        </div>
    </form>
</div>

<div class="row g-4">
    <?php if ($past_projects->num_rows > 0): ?>
        <?php while ($row = $past_projects->fetch_assoc()): ?>
            <div class="col-md-6">
                <div class="card card-custom p-4 h-100 border-start border-4 border-info">
                    <div class="d-flex justify-content-between align-items-start mb-2">
                        <span class="badge bg-primary"><?= sanitize($row['category']); ?></span>
                        <small class="text-muted fw-bold"><?= sanitize($row['session']); ?></small>
                    </div>
                    <h5 class="fw-bold text-dark"><?= sanitize($row['title']); ?></h5>
                    <p class="small text-muted mb-2">Oleh: <strong><?= sanitize($row['full_name']); ?></strong> (<?= sanitize($row['department']); ?>)</p>
                    <p class="small text-secondary"><?= substr(sanitize($row['description']), 0, 150); ?>...</p>
                </div>
            </div>
        <?php endwhile; ?>
    <?php else: ?>
        <div class="col-12 text-center py-5 text-muted">
            <i class="fas fa-folder-open fa-3x mb-3"></i>
            <h6>Tiada projek rujukan ditemui mengikut kriteria carian anda.</h6>
        </div>
    <?php endif; ?>
</div>

<?php include_once '../includes/footer_student.php'; ?>