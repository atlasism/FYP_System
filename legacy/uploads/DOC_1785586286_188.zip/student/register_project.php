<?php
require_once '../config/database.php';
require_once '../includes/auth_check.php';
check_access(['Student']);

$student_id = $_SESSION['user_id'];

// Semak jika sudah mendaftar projek
$stmt_check = $conn->prepare("SELECT id FROM projects WHERE student_id = ?");
$stmt_check->bind_param("i", $student_id);
$stmt_check->execute();
if ($stmt_check->get_result()->num_rows > 0) {
    header("Location: my_project.php");
    exit();
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = trim($_POST['title']);
    $department = $_SESSION['department'];
    $category = trim($_POST['category']);
    $session = trim($_POST['session']);
    $description = trim($_POST['description']);

    if (!empty($title) && !empty($category) && !empty($description)) {
        $stmt = $conn->prepare("INSERT INTO projects (student_id, title, department, category, session, description) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("isssss", $student_id, $title, $department, $category, $session, $description);
        
        if ($stmt->execute()) {
            header("Location: my_project.php");
            exit();
        } else {
            $error = "Ralat semasa mendaftarkan projek.";
        }
    } else {
        $error = "Sila lengkapkan semua maklumat wajib.";
    }
}

include_once '../includes/header.php';
include_once '../includes/navbar.php';
?>

<div class="container py-4">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card card-custom p-4">
                <h4 class="fw-bold mb-3"><i class="fas fa-plus-circle me-2 text-primary"></i>Pendaftaran Projek FYP</h4>
                
                <?php if ($error): ?><div class="alert alert-danger"><?= sanitize($error); ?></div><?php endif; ?>

                <form method="POST">
                    <div class="mb-3">
                        <label class="form-label fw-bold">Tajuk Projek</label>
                        <input type="text" name="title" class="form-control" placeholder="Contoh: Smart Attendance System using QR" required>
                    </div>

                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-bold">Jabatan</label>
                            <input type="text" class="form-control" value="<?= sanitize($_SESSION['department']); ?>" readonly>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-bold">Kategori Projek</label>
                            <select name="category" class="form-select" required>
                                <option value="">-- Pilih Kategori --</option>
                                <?php if ($_SESSION['department'] === 'JTMK'): ?>
                                    <option value="Web Application">Web Application</option>
                                    <option value="Mobile Application">Mobile Application</option>
                                    <option value="IoT & Networking">IoT & Networking</option>
                                <?php else: ?>
                                    <option value="Rekabentuk Visual">Rekabentuk Visual</option>
                                    <option value="Seni Kraf & Rekabentuk">Seni Kraf & Rekabentuk</option>
                                    <option value="Media Digital">Media Digital</option>
                                <?php endif; ?>
                            </select>
                        </div>
                    </div>

                    <div class="mb-3">
                        <label class="form-label fw-bold">Sesi Akademik</label>
                        <input type="text" name="session" class="form-control" value="Sesi 1 2026/2027" required>
                    </div>

                    <div class="mb-3">
                        <label class="form-label fw-bold">Penerangan / Abstrak Ringkas Projek</label>
                        <textarea name="description" rows="5" class="form-control" placeholder="Jelaskan secara ringkas mengenai fungsi utama projek..." required></textarea>
                    </div>

                    <button type="submit" class="btn btn-primary w-100 fw-bold py-2">Hantar Pendaftaran Projek</button>
                </form>
            </div>
        </div>
    </div>
</div>

<?php include_once '../includes/footer.php'; ?>