<?php
require_once '../config/database.php';
require_once '../includes/auth_check.php';
check_access(['Student']);

// Ambil projek dan senarai pelajar
$groups_res = $conn->query("
    SELECT p.title, p.category, p.session, u.full_name, u.matric_ic_num, u.department 
    FROM projects p 
    JOIN users u ON p.student_id = u.id 
    ORDER BY p.title ASC
");

include_once '../includes/sidebar_student.php';
?>

<div class="card card-custom p-4 mb-4">
    <h4 class="fw-bold text-primary mb-1"><i class="fas fa-users me-2"></i>Senarai Kumpulan & Projek Semasa</h4>
    <p class="text-muted mb-0">Senarai projek dan ahli kumpulan yang berdaftar dalam sistem bagi sesi ini.</p>
</div>

<div class="card card-custom p-4">
    <div class="table-responsive">
        <table class="table table-hover align-middle">
            <thead class="table-light">
                <tr>
                    <th>#</th>
                    <th>Nama Pelajar / Ahli</th>
                    <th>No. Matrik</th>
                    <th>Tajuk Projek</th>
                    <th>Kategori</th>
                    <th>Jabatan</th>
                </tr>
            </thead>
            <tbody>
                <?php if ($groups_res->num_rows > 0): $i=1; while ($g = $groups_res->fetch_assoc()): ?>
                    <tr>
                        <td><?= $i++; ?></td>
                        <td class="fw-bold text-primary"><?= sanitize($g['full_name']); ?></td>
                        <td><span class="badge bg-secondary"><?= sanitize($g['matric_ic_num']); ?></span></td>
                        <td><?= sanitize($g['title']); ?></td>
                        <td><span class="badge bg-info text-dark"><?= sanitize($g['category']); ?></span></td>
                        <td><?= sanitize($g['department']); ?></td>
                    </tr>
                <?php endwhile; else: ?>
                    <tr>
                        <td colspan="6" class="text-center py-4 text-muted">Tiada kumpulan / projek didaftarkan lagi.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php include_once '../includes/footer_student.php'; ?>