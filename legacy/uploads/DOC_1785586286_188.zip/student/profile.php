<?php
require_once '../config/database.php';
require_once '../includes/auth_check.php';
check_access(['Student']);

$student_id = $_SESSION['user_id'];
$message = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $full_name = trim($_POST['full_name']);
    $email = trim($_POST['email']);
    $password = $_POST['password'];

    if (!empty($full_name) && !empty($email)) {
        if (!empty($password)) {
            $hashed = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $conn->prepare("UPDATE users SET full_name = ?, email = ?, password = ? WHERE id = ?");
            $stmt->bind_param("sssi", $full_name, $email, $hashed, $student_id);
        } else {
            $stmt = $conn->prepare("UPDATE users SET full_name = ?, email = ? WHERE id = ?");
            $stmt->bind_param("ssi", $full_name, $email, $student_id);
        }

        if ($stmt->execute()) {
            $_SESSION['full_name'] = $full_name;
            $message = "Profil berjaya dikemaskini.";
        } else {
            $error = "Ralat kemaskini profil.";
        }
    }
}

// Ambil maklumat semasa
$stmt = $conn->prepare("SELECT * FROM users WHERE id = ?");
$stmt->bind_param("i", $student_id);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();

include_once '../includes/header.php';
include_once '../includes/navbar.php';
?>

<div class="container py-4">
    <div class="row justify-content-center">
        <div class="col-md-6">
            <div class="card card-custom p-4">
                <h4 class="fw-bold mb-3"><i class="fas fa-id-card me-2 text-primary"></i>Profil Saya</h4>
                
                <?php if ($message): ?><div class="alert alert-success py-2"><?= sanitize($message); ?></div><?php endif; ?>
                <?php if ($error): ?><div class="alert alert-danger py-2"><?= sanitize($error); ?></div><?php endif; ?>

                <form method="POST">
                    <div class="mb-3">
                        <label class="form-label fw-bold">Nombor Matrik</label>
                        <input type="text" class="form-control" value="<?= sanitize($user['matric_ic_num']); ?>" disabled>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-bold">Jabatan</label>
                        <input type="text" class="form-control" value="<?= sanitize($user['department']); ?>" disabled>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-bold">Nama Penuh</label>
                        <input type="text" name="full_name" class="form-control" value="<?= sanitize($user['full_name']); ?>" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-bold">E-mel</label>
                        <input type="email" name="email" class="form-control" value="<?= sanitize($user['email']); ?>" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-bold">Tukar Kata Laluan (Biarkan kosong jika tidak menukar)</label>
                        <input type="password" name="password" class="form-control" placeholder="******">
                    </div>
                    <button type="submit" class="btn btn-primary w-100 fw-bold">Simpan Profil</button>
                </form>
            </div>
        </div>
    </div>
</div>

<?php include_once '../includes/footer.php'; ?>