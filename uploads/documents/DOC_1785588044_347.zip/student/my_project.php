<?php
require_once '../config/database.php';
require_once '../includes/auth_check.php';
check_access(['Student']);

$student_id = $_SESSION['user_id'];
$success = '';
$error = '';

// 1. Semak maklumat projek pelajar semasa
$stmt = $conn->prepare("
    SELECT p.*, s.full_name as supervisor_name, s.email as supervisor_email 
    FROM projects p 
    LEFT JOIN users s ON p.supervisor_id = s.id 
    WHERE p.student_id = ?
");
$stmt->bind_param("i", $student_id);
$stmt->execute();
$project = $stmt->get_result()->fetch_assoc();

// 2. Ambil senarai Supervisor untuk pilihan dropdown
$supervisors = $conn->query("SELECT id, full_name, department FROM users WHERE role = 'Supervisor' ORDER BY full_name ASC");

// 3. Proses Pendaftaran / Kemaskini Projek
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title         = trim($_POST['title']);
    $category      = trim($_POST['category']);
    $session       = trim($_POST['session']);
    $description   = trim($_POST['description']);
    $supervisor_id = !empty($_POST['supervisor_id']) ? intval($_POST['supervisor_id']) : NULL;

    if (!empty($title) && !empty($category)) {
        if ($project) {
            // Kemaskini Projek
            $stmt_up = $conn->prepare("
                UPDATE projects 
                SET title = ?, category = ?, session = ?, description = ?, supervisor_id = ? 
                WHERE id = ? AND student_id = ?
            ");
            $stmt_up->bind_param("ssssiii", $title, $category, $session, $description, $supervisor_id, $project['id'], $student_id);
            
            if ($stmt_up->execute()) {
                $success = "Maklumat projek berjaya dikemaskini!";
                // Refresh data
                header("Refresh:1; url=my_project.php");
            } else {
                $error = "Ralat semasa kemaskini: " . $conn->error;
            }
        } else {
            // Daftar Projek Baharu
            $stmt_in = $conn->prepare("
                INSERT INTO projects (student_id, title, category, session, description, supervisor_id) 
                VALUES (?, ?, ?, ?, ?, ?)
            ");
            $stmt_in->bind_param("issssi", $student_id, $title, $category, $session, $description, $supervisor_id);
            
            if ($stmt_in->execute()) {
                $success = "Projek berjaya didaftarkan!";
                header("Refresh:1; url=my_project.php");
            } else {
                $error = "Ralat semasa pendaftaran: " . $conn->error;
            }
        }
    } else {
        $error = "Sila isi tajuk dan kategori projek.";
    }
}

include_once '../includes/sidebar_student.php';
?>

<div class="d-flex align-items-center justify-content-between mb-4">
    <div>
        <h3 class="fw-bold mb-1"><i class="fas fa-project-diagram text-primary me-2"></i>Maklumat Projek Saya</h3>
        <p class="text-muted mb-0">Pengurusan butiran Projek Tahun Akhir / SPInE anda.</p>
    </div>
</div>

<?php if (!empty($success)): ?>
    <div class="alert alert-success py-2 fw-bold mb-4">
        <i class="fas fa-check-circle me-1"></i> <?= sanitize($success); ?>
    </div>
<?php endif; ?>

<?php if (!empty($error)): ?>
    <div class="alert alert-danger py-2 fw-bold mb-4">
        <i class="fas fa-exclamation-triangle me-1"></i> <?= sanitize($error); ?>
    </div>
<?php endif; ?>

<div class="row g-4">
    <!-- Kad Paparan Maklumat Projek / Borang -->
    <div class="col-md-8">
        <div class="card card-custom p-4">
            <h5 class="fw-bold mb-3 border-bottom pb-2">
                <?= $project ? 'Kemaskini Maklumat Projek' : 'Daftar Projek Baharu'; ?>
            </h5>

            <form method="POST" action="">
                <div class="mb-3">
                    <label class="form-label fw-bold">Tajuk Projek *</label>
                    <input type="text" name="title" class="form-control" placeholder="Contoh: Sistem Pengurusan FYP Politeknik" value="<?= sanitize($project['title'] ?? ''); ?>" required>
                </div>

                <div class="row g-3 mb-3">
                    <div class="col-md-6">
                        <label class="form-label fw-bold">Kategori Projek *</label>
                        <select name="category" class="form-select" required>
                            <option value="">-- Pilih Kategori --</option>
                            <option value="Web Based" <?= (($project['category'] ?? '') === 'Web Based') ? 'selected' : ''; ?>>Web Based</option>
                            <option value="Mobile App" <?= (($project['category'] ?? '') === 'Mobile App') ? 'selected' : ''; ?>>Mobile App</option>
                            <option value="IoT / Hardware" <?= (($project['category'] ?? '') === 'IoT / Hardware') ? 'selected' : ''; ?>>IoT / Hardware</option>
                            <option value="Network / Security" <?= (($project['category'] ?? '') === 'Network / Security') ? 'selected' : ''; ?>>Network / Security</option>
                        </select>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label fw-bold">Sesi Pengajian</label>
                        <input type="text" name="session" class="form-control" placeholder="Contoh: SESI 1 2024/2025" value="<?= sanitize($project['session'] ?? 'SESI 1 2024/2025'); ?>">
                    </div>
                </div>

                <div class="mb-3">
                    <label class="form-label fw-bold">Pilih Penyelia (Supervisor)</label>
                    <select name="supervisor_id" class="form-select">
                        <option value="">-- Belum Ditentukan / Tetapkan Kemudian --</option>
                        <?php if ($supervisors && $supervisors->num_rows > 0): ?>
                            <?php while ($s = $supervisors->fetch_assoc()): ?>
                                <option value="<?= $s['id']; ?>" <?= (($project['supervisor_id'] ?? '') == $s['id']) ? 'selected' : ''; ?>>
                                    <?= sanitize($s['full_name']); ?> (<?= sanitize($s['department']); ?>)
                                </option>
                            <?php endwhile; ?>
                        <?php endif; ?>
                    </select>
                </div>

                <div class="mb-4">
                    <label class="form-label fw-bold">Keterangan / Abstrak Projek</label>
                    <textarea name="description" class="form-control" rows="5" placeholder="Ringkasan mengenai objektif dan penyelesaian projek..."><?= sanitize($project['description'] ?? ''); ?></textarea>
                </div>

                <button type="submit" class="btn btn-primary fw-bold py-2 w-100">
                    <i class="fas fa-save me-1"></i> <?= $project ? 'Simpan Perubahan' : 'Daftar Projek'; ?>
                </button>
            </form>
        </div>
    </div>

    <!-- Kad Maklumat Penyelia & Status -->
    <div class="col-md-4">
        <div class="card card-custom p-4 mb-3 border-start border-4 border-info">
            <h6 class="fw-bold text-muted mb-2">PENYELIA DILANTIK</h6>
            <h5 class="fw-bold text-dark mb-1">
                <?= sanitize($project['supervisor_name'] ?? 'Belum Ada'); ?>
            </h5>
            <small class="text-muted d-block mb-3"><?= sanitize($project['supervisor_email'] ?? '-'); ?></small>
            
            <div class="p-3 bg-light rounded-3">
                <small class="text-secondary d-block"><i class="fas fa-info-circle me-1"></i> Hubungi penyelia anda untuk sebarang perbincangan atau semakan draf dokumen.</small>
            </div>
        </div>

        <div class="card card-custom p-4 border-start border-4 border-success">
            <h6 class="fw-bold text-muted mb-2">STATUS PENILAIAN</h6>
            <h5 class="fw-bold mb-0">
                <?php if ($project && ($project['is_complete_for_evaluation'] ?? 0)): ?>
                    <span class="text-success"><i class="fas fa-check-circle me-1"></i> Layak Dinilai</span>
                <?php else: ?>
                    <span class="text-warning"><i class="fas fa-clock me-1"></i> Memerlukan Dokumen Lengkap</span>
                <?php endif; ?>
            </h5>
        </div>
    </div>
</div>

<?php include_once '../includes/footer.php'; ?>