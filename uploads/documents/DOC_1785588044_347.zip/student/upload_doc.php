<?php
require_once '../config/database.php';
require_once '../includes/auth_check.php';
check_access(['Student']);

$student_id = $_SESSION['user_id'];
$error = '';
$success = '';

// 1. Ambil ID & Maklumat Projek Pelajar
$stmt = $conn->prepare("SELECT id FROM projects WHERE student_id = ?");
$stmt->bind_param("i", $student_id);
$stmt->execute();
$project = $stmt->get_result()->fetch_assoc();

if (!$project) {
    header("Location: my_project.php");
    exit();
}

// 2. Proses Muat Naik Dokumen
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $doc_type = trim($_POST['doc_type']);
    $file = $_FILES['document'] ?? null;

    if (!empty($doc_type) && isset($file) && $file['error'] === 0) {
        $allowed_ext = ['pdf', 'doc', 'docx', 'ppt', 'pptx', 'zip', 'rar'];
        $file_name = $file['name'];
        $file_tmp = $file['tmp_name'];
        $file_ext = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));

        if (in_array($file_ext, $allowed_ext)) {
            // Cipta nama fail unik
            $new_file_name = "DOC_" . time() . "_" . rand(100, 999) . "." . $file_ext;
            $upload_dir = "../uploads/";

            if (!is_dir($upload_dir)) {
                mkdir($upload_dir, 0777, true);
            }

            if (move_uploaded_file($file_tmp, $upload_dir . $new_file_name)) {
                $stmt_in = $conn->prepare("INSERT INTO project_documents (project_id, doc_type, file_path) VALUES (?, ?, ?)");
                $stmt_in->bind_param("iss", $project['id'], $doc_type, $new_file_name);
                
                if ($stmt_in->execute()) {
                    $success = "Dokumen (" . sanitize($doc_type) . ") berjaya dimuat naik!";
                } else {
                    $error = "Ralat pangkalan data: " . $conn->error;
                }
            } else {
                $error = "Gagal memuat naik fail ke folder pelayan.";
            }
        } else {
            $error = "Format fail tidak dibenarkan. Sila muat naik PDF, Word, PowerPoint, atau ZIP/RAR sahaja.";
        }
    } else {
        $error = "Sila pilih jenis dokumen dan fail yang sah.";
    }
}

// 3. Ambil Senarai Dokumen Yang Telah Dimuat Naik Oleh Pelajar
$stmt_docs = $conn->prepare("SELECT * FROM project_documents WHERE project_id = ? ORDER BY uploaded_at DESC");
$stmt_docs->bind_param("i", $project['id']);
$stmt_docs->execute();
$my_documents = $stmt_docs->get_result();

include_once '../includes/sidebar_student.php';
?>

<div class="d-flex align-items-center justify-content-between mb-4">
    <div>
        <h3 class="fw-bold mb-1"><i class="fas fa-file-upload text-primary me-2"></i>Muat Naik Dokumen</h3>
        <p class="text-muted mb-0">Hantar draf, laporan, slaid pembentangan, atau kod sumber projek anda.</p>
    </div>
    <a href="dashboard.php" class="btn btn-outline-secondary btn-sm"><i class="fas fa-arrow-left me-1"></i> Kembali ke Dashboard</a>
</div>

<?php if (!empty($success)): ?>
    <div class="alert alert-success py-2 fw-bold mb-4">
        <i class="fas fa-check-circle me-1"></i> <?= sanitize($success); ?>
    </div>
<?php endif; ?>

<?php if (!empty($error)): ?>
    <div class="alert alert-danger py-2 fw-bold mb-4">
        <i class="fas fa-exclamation-triangle me-1"></i> <?= sanitize($error); ?>
    </div>
<?php endif; ?>

<div class="row g-4">
    <!-- Borang Muat Naik Dokumen -->
    <div class="col-md-5">
        <div class="card card-custom p-4">
            <h5 class="fw-bold mb-3 border-bottom pb-2"><i class="fas fa-plus-circle text-primary me-1"></i> Borang Muat Naik</h5>
            
            <form method="POST" action="" enctype="multipart/form-data">
                <div class="mb-3">
                    <label class="form-label fw-bold">Jenis Dokumen *</label>
                    <select name="doc_type" class="form-select" required>
                        <option value="">-- Pilih Jenis Dokumen --</option>
                        <option value="Proposal Projek">Proposal Projek</option>
                        <option value="Laporan Akhir (Draft)">Laporan Akhir (Draft)</option>
                        <option value="Laporan Akhir (Muktamat)">Laporan Akhir (Muktamat)</option>
                        <option value="Poster Projek">Poster Projek</option>
                        <option value="Slaid Pembentangan">Slaid Pembentangan</option>
                        <option value="Atur Cara / Kod Sumber (ZIP)">Atur Cara / Kod Sumber (ZIP)</option>
                    </select>
                </div>

                <div class="mb-4">
                    <label class="form-label fw-bold">Pilih Fail *</label>
                    <input type="file" name="document" class="form-control" required>
                    <small class="text-muted d-block mt-1">Format: PDF, DOC, DOCX, PPT, PPTX, ZIP, RAR (Maks 20MB)</small>
                </div>

                <button type="submit" class="btn btn-primary fw-bold py-2 w-100">
                    <i class="fas fa-upload me-1"></i> Muat Naik Dokumen
                </button>
            </form>
        </div>
    </div>

    <!-- Jadual Senarai Dokumen Yang Telah Dimuat Naik -->
    <div class="col-md-7">
        <div class="card card-custom p-4">
            <h5 class="fw-bold mb-3 border-bottom pb-2"><i class="fas fa-list text-primary me-1"></i> Senarai Dokumen Dihantar</h5>
            
            <div class="table-responsive">
                <table class="table table-hover align-middle">
                    <thead class="table-light">
                        <tr>
                            <th>#</th>
                            <th>Jenis Dokumen</th>
                            <th>Tarikh Muat Naik</th>
                            <th>Tindakan</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if ($my_documents && $my_documents->num_rows > 0): $i = 1; ?>
                            <?php while ($doc = $my_documents->fetch_assoc()): ?>
                                <tr>
                                    <td><?= $i++; ?></td>
                                    <td>
                                        <strong class="text-dark"><?= sanitize($doc['doc_type']); ?></strong>
                                    </td>
                                    <td>
                                        <small class="text-muted"><?= date('d/m/Y h:i A', strtotime($doc['uploaded_at'] ?? 'now')); ?></small>
                                    </td>
                                    <td>
                                        <a href="../uploads/<?= sanitize($doc['file_path']); ?>" target="_blank" class="btn btn-sm btn-outline-primary">
                                            <i class="fas fa-download me-1"></i> Muat Turun
                                        </a>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="4" class="text-center py-4 text-muted">
                                    <i class="fas fa-folder-open fa-2x mb-2 d-block"></i>
                                    Belum ada dokumen yang dimuat naik.
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php include_once '../includes/footer.php'; ?>