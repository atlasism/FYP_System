<?php
require_once '../config/database.php';
require_once '../includes/auth_check.php';
check_access(['Student']);

$student_id = $_SESSION['user_id'];

// 1. Semak projek pelajar
$stmt = $conn->prepare("SELECT id FROM projects WHERE student_id = ?");
$stmt->bind_param("i", $student_id);
$stmt->execute();
$project = $stmt->get_result()->fetch_assoc();

// 2. Semak kebenaran/flag paparan markah dari Admin/Supervisor
// (Secara lalai $can_view_marks diset mengikut status kebenaran)
$can_view_marks = true; // Tukar logic ini mengikut kolum database anda contoh: $project['show_marks'] == 1

// Contoh struktur data penilaian rubrik
$rubrics = [
    ['component' => 'Proposal & Pembentangan Awal', 'weight' => '20%', 'score' => 16, 'max' => 20],
    ['component' => 'Laporan Kemajuan (Draft)', 'weight' => '30%', 'score' => 25, 'max' => 30],
    ['component' => 'Pembangunan Sistem / Output Projek', 'weight' => '30%', 'score' => 27, 'max' => 30],
    ['component' => 'Pembentangan Akhir & Demo', 'weight' => '20%', 'score' => 18, 'max' => 20],
];

$total_score = array_sum(array_column($rubrics, 'score'));

include_once '../includes/sidebar_student.php';
?>

<div class="card card-custom p-4 mb-4">
    <h4 class="fw-bold text-primary mb-1"><i class="fas fa-chart-line me-2"></i>Markah Penilaian Projek</h4>
    <p class="text-muted mb-0">Keputusan penilaian semasa berdasarkan rubrik yang ditetapkan oleh Penyelia dan Penilai.</p>
</div>

<?php if (!$can_view_marks): ?>
    <!-- Amaran jika paparan markah belum dibuka -->
    <div class="alert alert-warning card-custom p-5 text-center">
        <i class="fas fa-lock fa-3x mb-3 text-warning"></i>
        <h5 class="fw-bold">Paparan Markah Belum Diumumkan</h5>
        <p class="mb-0 text-muted">Semakan markah belum dibuka oleh Pentadbir atau Penyelia lagi. Sila semak semula kemudian.</p>
    </div>
<?php else: ?>
    <div class="row g-4">
        <!-- Cad Ringkasan Markah -->
        <div class="col-md-4">
            <div class="card card-custom p-4 text-center h-100 d-flex flex-column justify-content-center">
                <small class="text-muted fw-bold">JUMLAH MARKAH KESELURUHAN</small>
                <h1 class="display-3 fw-bold text-primary my-2"><?= $total_score; ?><span class="fs-4 text-muted">/100</span></h1>
                <div>
                    <span class="badge bg-success fs-6 px-3 py-2">Gred Cemerlang</span>
                </div>
            </div>
        </div>

        <!-- Pecahan Rubrik -->
        <div class="col-md-8">
            <div class="card card-custom p-4">
                <h6 class="fw-bold mb-3">Pecahan Rubrik Penilaian:</h6>
                <div class="table-responsive">
                    <table class="table align-middle">
                        <thead class="table-light">
                            <tr>
                                <th>Komponen Penilaian</th>
                                <th>Pemberat</th>
                                <th>Markah Diperoleh</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($rubrics as $r): ?>
                                <tr>
                                    <td class="fw-bold"><?= $r['component']; ?></td>
                                    <td><span class="badge bg-secondary"><?= $r['weight']; ?></span></td>
                                    <td class="fw-bold text-success"><?= $r['score']; ?> / <?= $r['max']; ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php endif; ?>

<?php include_once '../includes/footer.php'; ?>